<h1 align="center">⚡ Superbiz Uploader ⚡</h1>
<h3 align="center">This program will allow automate the process of uploading the ads to roblox and back to superbiz.</h3>

# Notices 
- This program is not affiliated with Superbiz, it is created by a user of the service (Adaks#0001 - 519182822616072217)
- By running the program, you agree for all of the ads to be uploaded
#
- Please install this version of python (3.10) to ensure everything works as smoothly as possible, if you have any other versions of python - remove them
- During installation, make sure to check "Add to PATH' - otherwise you will not be able to install required modules
- https://www.python.org/downloads/release/python-3100/
#
**Donations to support my work is massively appreciated**

<a href="https://www.buymeacoffee.com/adaks"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&emoji=&slug=adaks&button_colour=FFDD00&font_colour=000000&font_family=Poppins&outline_colour=000000&coffee_colour=ffffff" /></a>

<h1 align="center">Instructions</h1>

# Step 1
- Click [here](https://github.com/Adaaks/Superbiz-Uploader/archive/refs/heads/main.zip) to download the program

# Step 2

- Extract the ZIP, otherwise it will not function

![alt text](https://cdn.discordapp.com/attachments/854241200622403586/1014540260853682197/unknown.png)


# Step 3

- Open the folder, till you get to this page - now replace the url bar with: cmd. After, press enter.

![alt text](https://cdn.discordapp.com/attachments/854241200622403586/1014541317067514026/unknown.png)


# Step 4

- Ensure you have Python version 3.10
- Paste in this into the command prompt, to install all python modules:
```
pip install -r Requirements.txt
```

![alt text](https://cdn.discordapp.com/attachments/698329423715369042/1035340120171216926/unknown.png)

If you receive an error like:
```
'pip' is not recognised as an interal or external command
```
- This means during python installation, you didn't check the 'Add to PATH' box, you must re-install python with this checkbox ticked!


# Step 5

- Open up Setup.ini, paste in roblox cookie (full contents of it, and do not put it in speech marks)
- If your unaware how to retrieve your roblox cookie, please download [this](https://chrome.google.com/webstore/detail/editthiscookie/fngmhnnpilhplaeedifhccceomclgfbg) chrome extension
- Then, go to the roblox page, click on the extension, go to .ROBLOSECURITY, and copy all contents inside it (3)
![alt text](https://cdn.discordapp.com/attachments/698329423715369042/1035343906142953472/unknown.png)
#
- Next, you will need to enter your superbiz email and password that you used to login into the site, this will be used to submit the ads

![alt text](https://cdn.discordapp.com/attachments/854241200622403586/1014541172699570277/unknown.png)


# Step 6

- You're now ready to open up Superbiz Uploader.py
- You will be welcomed into the program (with the name you used for superbiz account settings)
- You may have to wait a couple seconds for your games to load
- You will will be prompted to enter which game you would like to choose
- The program will show you the game's ad revenue for current and previous month
- Then, the program will begin uploading if your roblox cookie was correct
